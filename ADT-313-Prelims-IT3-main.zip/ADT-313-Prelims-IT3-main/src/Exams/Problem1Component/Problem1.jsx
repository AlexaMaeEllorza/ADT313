function User() {
    return(
        <div className="text-black">
            <h1>ALexa Mae I. Ellorza</h1>
            <h1>BSIT 3A</h1>
        </div>
    )

}
export default User;