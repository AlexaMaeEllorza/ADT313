import React, { useReducer } from 'react';
import data from './problem8mock_data.json';

// Define action types
const ACTIONS = {
  CREATE: 'create',
  READ: 'read',
  UPDATE: 'update',
  DELETE: 'delete',
  CLEAR: 'clear'
};

// Initial state
const initialState = {
  foods: data,
  selected: null
};

// Reducer function
const reducer = (state, action) => {
  switch (action.type) {
    case ACTIONS.CREATE:
      // Create a new array with the new food item added
      return { ...state, foods: [...state.foods, action.payload] };
    case ACTIONS.READ:
      return { ...state, selected: action.payload };
    case ACTIONS.UPDATE:
      const updatedFoods = state.foods.map(food =>
        food.food_name === action.payload.food_name ? action.payload : food
      );
      return { ...state, foods: updatedFoods, selected: null };
    case ACTIONS.DELETE:
      return { ...state, foods: state.foods.filter(food => food.food_name !== action.payload) };
    case ACTIONS.CLEAR:
      return { ...state, selected: null };
    default:
      return state;
  }
};

export default function Problem8() {
  const [state, dispatch] = useReducer(reducer, initialState);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    dispatch({ type: ACTIONS.READ, payload: { ...state.selected, [name]: value } });
  };

  const handleSave = () => {
    if (state.selected) {
      dispatch({ type: ACTIONS.UPDATE, payload: state.selected });
    } else {
      // Create new food item with empty fields
      const newFood = {
        food_name: '',
        price: '',
        expiration_date: '',
        calories: ''
      };
      dispatch({ type: ACTIONS.CREATE, payload: newFood });
    }
  };

  const handleEdit = (food) => {
    dispatch({ type: ACTIONS.READ, payload: food });
  };

  const handleDelete = (foodName) => {
    dispatch({ type: ACTIONS.DELETE, payload: foodName });
  };

  const handleClear = () => {
    dispatch({ type: ACTIONS.CLEAR });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            name='food_name'
            type='text'
            value={state.selected ? state.selected.food_name : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            name='price'
            type='text'
            value={state.selected ? state.selected.price : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            name='expiration_date'
            type='text'
            value={state.selected ? state.selected.expiration_date : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            name='calories'
            type='text'
            value={state.selected ? state.selected.calories : ''}
            onChange={handleInputChange}
          />
        </div>

        <button type='button' onClick={handleSave}>Save</button>
        <button type='button' onClick={handleClear}>Clear</button>
      </div>

      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {state.foods.map((food) => (
              <tr key={food.food_name}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(food)}>Edit</button>
                  <button type='button' onClick={() => handleDelete(food.food_name)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}