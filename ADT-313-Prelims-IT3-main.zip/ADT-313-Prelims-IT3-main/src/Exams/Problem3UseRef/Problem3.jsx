import React, { useRef } from 'react';

  function Problem3() {
  const input1Ref = useRef(null);
  const input2Ref = useRef(null);
  const input3Ref = useRef(null);
  const input4Ref = useRef(null);
  const input5Ref = useRef(null);
  const input6Ref = useRef(null);
  const input7Ref = useRef(null);
  const input8Ref = useRef(null);
  const input9Ref = useRef(null);
  const input10Ref = useRef(null);

  const handleButtonClick = () => {
  
    if (input1Ref.current && input1Ref.current.value === '') {
      input1Ref.current.focus();
    } else if (input2Ref.current && input2Ref.current.value === '') {
      input2Ref.current.focus();
    } else if (input3Ref.current && input3Ref.current.value === '') {
      input3Ref.current.focus();
    } else if (input4Ref.current && input4Ref.current.value === '') {
      input4Ref.current.focus();
    } else if (input5Ref.current && input5Ref.current.value === '') {
      input5Ref.current.focus();
    } else if (input6Ref.current && input6Ref.current.value === '') {
      input6Ref.current.focus();
    } else if (input7Ref.current && input7Ref.current.value === '') {
      input7Ref.current.focus();
    } else if (input8Ref.current && input8Ref.current.value === '') {
      input8Ref.current.focus();
    } else if (input9Ref.current && input9Ref.current.value === '') {
      input9Ref.current.focus();
    } else if (input10Ref.current && input10Ref.current.value === '') {
      input10Ref.current.focus();
    }
  }
  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input type='text' ref={input1Ref} />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input type='text' ref={input2Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input type='text' ref={input3Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input type='text' ref={input4Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input type='text' ref={input5Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input type='text' ref={input6Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input type='text' ref={input7Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input type='text' ref={input8Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input type='text' ref={input9Ref}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input type='text' ref={input10Ref}/>
      </div>

      <button type='button' onClick={handleButtonClick}>
        I'm a button
      </button>
    </>
  );
}



export default Problem3;
